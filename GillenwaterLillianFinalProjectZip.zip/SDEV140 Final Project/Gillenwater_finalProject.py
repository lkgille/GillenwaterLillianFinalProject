"""
Final Project for SDEV140

"""

from breezypythongui import EasyFrame
from tkinter import *
from tkinter import PhotoImage
from tkinter.font import Font
from tkinter import messagebox
import os
# from tkinter import filedialog


class SplashScreen(EasyFrame):
    # Displays splash screen
    def __init__(self):
        EasyFrame.__init__(self, "Music Library")
        self.setResizable(False)
        imageLabel = self.addLabel(text="", row=0, column = 1, sticky = "NSEW")
        textLabel = self.addLabel(text = "Welcome to the music library. What would you like to do?", row = 1, column = 1, sticky = "NSEW")

        # Load image and associate it with the image label
        self.image = PhotoImage(file = "musicLogo5.png")
        imageLabel["image"] = self.image

        # Set font and color 
        font = Font(family = "Verdana", size = 12, slant = "roman", weight = "bold")
        textLabel["font"] = font
        textLabel["foreground"] = "SkyBlue2"

        self.addButton(text = "Manage songs", row = 2, column = 0, command = self.openSongWindow) #command = self.manageSongs)
        self.addButton(text = "Manage artists", row = 2, column = 1, command = self.openArtistWindow)
        self.addButton(text = "Click to exit", row = 2, column = 2, command = lambda:quit()) # self.close resize ? / add padding

    def openArtistWindow(self):
        artistWindow(self)

    def openSongWindow(self):
        songWindow(self)

""" Artist Window """

class artistWindow(EasyFrame):
    # Opens the window to manage or view artists
    def __init__(self, master):
        EasyFrame.__init__(self, "Music Library")
        self.setResizable(False)

        self.addLabel(text = "Add Artist", row = 0, column = 0)
        self.addLabel(text = "Artist name:", row = 2, column = 0)
        self.addLabel(text = "Current list:", row = 1, column = 0)

        self.artistField = self.addTextField(text = "", row = 2, column = 1)  
        self.listArea = self.addTextArea(text = "", row = 1, column = 0, columnspan = 3)  # Area to display the list of artists

        self.addButton(text = "Add", row = 4, column = 0, command = self.addArtist)
        self.addButton(text = "Delete", row = 4, column = 1, command = self.deleteArtist)
        self.addButton(text = "Close", row = 4, column = 2, command = self.close)

        # Set font and color for Add Artist title
        font = Font(family="Verdana", size = 12, slant = "roman", weight = "bold")
        self.addLabel(text="Add or delete an artist", row = 0, column = 0, font = font, foreground = "SkyBlue2")

        self.artist_list = []
        self.loadArtists()
        
    def addArtist(self):
        artist = self.artistField.getText()
        if artist == "":
            messagebox.showerror(message = "Please type in the text box to add an artist.")
        if artist:
            self.artist_list.append(artist)
            self.listArea.setText("\n".join(self.artist_list))
            self.artistField.setText("")
            self.saveArtists()

    def deleteArtist(self):
        artist_to_delete = self.artistField.getText()
        if artist_to_delete == "":
            messagebox.showerror(message = "Please type in the text box to delete an artist.")
        elif artist_to_delete in self.artist_list:
            self.artist_list.remove(artist_to_delete)
            self.listArea.setText("\n".join(self.artist_list))
            self.artistField.setText("")  # Clear the delete field
            self.saveArtists()  # Save changes after deletion
        else:
            messagebox.showerror(message="Artist not found in the list.")

    def saveArtists(self):
        with open("artists.txt", "w") as f: # Opens a new file to save the list of artists to
            for artist in self.artist_list:
                f.write(artist + "\n")

    def loadArtists(self):
        if os.path.exists("artists.txt"):
            with open("artists.txt", "r") as f:
                self.artist_list = [line.strip() for line in f.readlines()]
            self.listArea.setText("\n".join(self.artist_list))

    def close(self):
        self.saveArtists() # Saves the list for the next time the program is opened
        self.destroy()
                  
        
        

        # if 


        # if input is not a string, messagebox.showerror(message = "")


""" Song Window """

class songWindow(EasyFrame):
    # Opens the window to manage or view songs
    def __init__(self, master):
        EasyFrame.__init__(self, "Music Library")
        self.setResizable(False)

        self.addLabel(text = "Add Song", row = 0, column = 0)
        self.addLabel(text = "Song name and artist:", row = 2, column = 0)
        self.addLabel(text = "Current list:", row = 1, column = 0)

        self.songField = self.addTextField(text = "", row = 2, column = 1)  
        self.listArea = self.addTextArea(text = "", row = 1, column = 0, columnspan = 3)  # Area to display list

        self.addButton(text = "Add", row = 4, column = 0, command = self.addSong)
        self.addButton(text = "Delete", row = 4, column = 1, command = self.deleteSong)
        self.addButton(text = "Close", row = 4, column = 2, command = self.close)

        # Set font and color for Add Song title
        font = Font(family = "Verdana", size = 12, slant = "roman", weight = "bold")
        self.addLabel(text = "Add Song", row = 0, column = 0, font = font, foreground = "SkyBlue2")

        self.song_list = []
        self.loadSongs()

    def addSong(self):
        song = self.songField.getText()
        if song == "":
            messagebox.showerror(message = "Please type in the text box to add a song.")
        if song:
            self.song_list.append(song)
            self.listArea.setText("\n".join(self.song_list))
            self.songField.setText("")
            self.saveSongs()

    def deleteSong(self):
        song_to_delete = self.songField.getText.upper()
        if song_to_delete == "":
            messagebox.showerror(message = "Please type in the text box to delete an artist.") 
        elif song_to_delete in self.song_list:
            self.song_list.remove(song_to_delete)
            self.listArea.setText("\n".join(self.song_list))
            self.songField.setText("")  # Clear the delete field
            self.saveSongs()  # Save changes after deletion
        else:
            messagebox.showerror(message="Artist not found in the list.")

    def saveSongs(self):
        with open("songs.txt", "w") as f: # Opens a new file to save the list of songs
            for song in self.song_list:
                f.write(song + "\n")

    def loadSongs(self):
        if os.path.exists("songs.txt"):
            with open("songs.txt", "r") as f:
                self.song_list = [line.strip() for line in f.readlines()]
            self.listArea.setText("\n".join(self.song_list))

    def close(self):
        self.saveSongs() # Saves the list for the next time the program is opened
        self.destroy() # Closes the window


def main ():
    """ Instantiate and pop up the window. """
    SplashScreen().mainloop()

if __name__ == "__main__":
    main()
