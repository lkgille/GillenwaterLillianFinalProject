"""
Final Project for SDEV140

File name: GillenwaterLillianFinalProject

This program is meant to be a place where the user can input songs or artists
and save them to a list.

"""

from breezypythongui import EasyFrame
from tkinter import PhotoImage
from tkinter.font import Font
from tkinter import messagebox
import os

class SplashScreen(EasyFrame):
    # Displays splash screen
    def __init__(self):
        EasyFrame.__init__(self, "Music Library")
        self.setResizable(False)
        imageLabel = self.addLabel(text="", row=0, column = 1, sticky = "NSEW")
        textLabel = self.addLabel(text = "Welcome to the music library. What would you like to do?", row = 1, column = 1, sticky = "NSEW")

        # Load image and associate it with the image label
        self.image = PhotoImage(file = "musicLogo5.png")
        imageLabel["image"] = self.image

        # Set font and color 
        font = Font(family = "Verdana", size = 12, slant = "roman", weight = "bold")
        textLabel["font"] = font
        textLabel["foreground"] = "SkyBlue2"

        self.addButton(text = "Manage songs", row = 2, column = 0, command = self.openSongWindow) #command = self.manageSongs)
        self.addButton(text = "Manage artists", row = 2, column = 1, command = self.openArtistWindow)
        self.addButton(text = "Click to exit", row = 2, column = 2, command = lambda:quit()) # self.close resize ? / add padding

    def openArtistWindow(self):
        artistWindow(self)

    def openSongWindow(self):
        songWindow(self)

""" Artist Window """

class artistWindow(EasyFrame):
    # Opens the window to manage or view artists
    def __init__(self, master):
        EasyFrame.__init__(self, "Music Library")
        self.setResizable(False)

        imageLabel = self.addLabel(text="", row=0, column = 1, sticky = "NSEW")
        self.image = PhotoImage(file = "musiclogo10.png")
        imageLabel["image"] = self.image

        self.addLabel(text = "Add Artist", row = 0, column = 0)
        self.addLabel(text = "Artist name:", row = 2, column = 0)
        self.addLabel(text = "Current list:", row = 1, column = 0)

        self.artistField = self.addTextField(text = "", row = 2, column = 1)  
        self.listArea = self.addTextArea(text = "", row = 1, column = 0, columnspan = 3)  # Area to display the list of artists

        self.addButton(text = "Add", row = 4, column = 0, command = self.addArtist)
        self.addButton(text = "Delete", row = 4, column = 1, command = self.deleteArtist)
        self.addButton(text="Sort alphabetically", row=4, column=2,  command=self.sortArtists)
        self.addButton(text = "Close", row = 4, column = 3, command = self.close)

        # Set font and color for Add Artist title
        font = Font(family="Verdana", size = 12, slant = "roman", weight = "bold")
        self.addLabel(text="Add or delete an artist", row = 0, column = 0, font = font, foreground = "SkyBlue2")

        self.artist_list = [] # Creates a list to be added to
        self.loadArtists() # Loads what is already in the list
        
    def addArtist(self):
        artist = self.artistField.getText() # Retrieves text from input field and assigns it to "artist" variable
        if artist == "":
            messagebox.showerror(message = "Please type in the text box to add an artist.")
        if artist: # Adds input to the list
            self.artist_list.append(artist)
            self.listArea.setText("\n".join(self.artist_list))
            self.artistField.setText("")
            self.saveArtists()

    def deleteArtist(self):
        artist_to_delete = self.artistField.getText().strip()
        if artist_to_delete == "": # If nothing is in the text field, shows an error
            messagebox.showerror(message="Please type in the text box to delete an artist.")
            return
        
        artist_to_delete_lower = artist_to_delete.lower() # Gets rid of case sensitivity to delete
        for artist in self.artist_list:
            if artist.lower() == artist_to_delete_lower:
                self.artist_list.remove(artist)
                self.listArea.setText("\n".join(self.artist_list))
                self.artistField.setText("")
                self.saveArtists()
                return

        messagebox.showerror(message = "Artist not found in the list.")            

    def sortArtists(self):
        self.artist_list.sort()  # Sort the list alphabetically
        self.listArea.setText("\n".join(self.artist_list))
        self.saveArtists()  # Save the sorted list

    def saveArtists(self):
        with open("artists.txt", "w") as f: # Opens a new file to save the list of artists to
            for artist in self.artist_list:
                f.write(artist + "\n")

    def loadArtists(self):
        if os.path.exists("artists.txt"):
            with open("artists.txt", "r") as f:
                self.artist_list = [line.strip() for line in f.readlines()]
            self.listArea.setText("\n".join(self.artist_list))

    def close(self):
        self.saveArtists() # Saves the list for the next time the program is opened
        self.destroy()

""" Song Window """

class songWindow(EasyFrame):
    # Opens the window to manage or view songs
    def __init__(self, master):
        EasyFrame.__init__(self, "Music Library")
        self.setResizable(False)

        self.addLabel(text = "Add Song", row = 0, column = 0)
        self.addLabel(text = "Song name and artist:", row = 2, column = 0)
        self.addLabel(text = "Current list:", row = 1, column = 0)

        self.songField = self.addTextField(text = "", row = 2, column = 1)  
        self.listArea = self.addTextArea(text = "", row = 1, column = 0, columnspan = 3)  # Area to display list

        self.addButton(text = "Add", row = 4, column = 0, command = self.addSong)
        self.addButton(text = "Delete", row = 4, column = 1, command = self.deleteSong)
        self.addButton(text="Sort alphabetically", row=4, column=2,  command=self.sortSongs)
        self.addButton(text = "Close", row = 4, column = 3, command = self.close)

        # Set font and color for Add Song title
        font = Font(family = "Verdana", size = 12, slant = "roman", weight = "bold")
        self.addLabel(text = "Add or delete a song", row = 0, column = 0, font = font, foreground = "SkyBlue2")

        self.song_list = [] # Creates a list to be added to
        self.loadSongs() # Loads what is already in the list

    def addSong(self):
        song = self.songField.getText() # Retrieves text from input field and assigns it to "song" variable
        if song == "":
            messagebox.showerror(message = "Please type in the text box to add a song.")
        if song: # Adds input to the list
            self.song_list.append(song)
            self.listArea.setText("\n".join(self.song_list))
            self.songField.setText("")
            self.saveSongs()

    def deleteSong(self):
        song_to_delete = self.songField.getText().strip()
        if song_to_delete == "": # If nothing is in the text field, shows an error
            messagebox.showerror(message="Please type in the text box to delete a song.")
            return
        
        song_to_delete_lower = song_to_delete.lower() # Gets rid of case sensitivity to delete
        for song in self.song_list:
            if song.lower() == song_to_delete_lower:
                self.song_list.remove(song)
                self.listArea.setText("\n".join(self.song_list))
                self.songField.setText("")
                self.saveSongs()
                return

        messagebox.showerror(message = "Song not found in the list.")

    def sortSongs(self):
        self.song_list.sort()  # Sort the list alphabetically
        self.listArea.setText("\n".join(self.song_list))
        self.saveSongs()  # Save the sorted list

    def saveSongs(self):
        with open("songs.txt", "w") as f: # Opens a new file to save the list of songs
            for song in self.song_list:
                f.write(song + "\n")

    def loadSongs(self):
        if os.path.exists("songs.txt"): 
            with open("songs.txt", "r") as f:
                self.song_list = [line.strip() for line in f.readlines()]
            self.listArea.setText("\n".join(self.song_list))

    def close(self):
        self.saveSongs() # Saves the list for the next time the program is opened
        self.destroy() # Closes the window


def main ():
    """ Instantiate and pop up the window. """
    SplashScreen().mainloop()

if __name__ == "__main__":
    main()
